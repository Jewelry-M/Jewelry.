---
name: Eternal Minimalist
colors:
  surface: '#faf9f7'
  surface-dim: '#dadad8'
  surface-bright: '#faf9f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f1'
  surface-container: '#efeeec'
  surface-container-high: '#e9e8e6'
  surface-container-highest: '#e3e2e0'
  on-surface: '#1a1c1b'
  on-surface-variant: '#444748'
  inverse-surface: '#2f3130'
  inverse-on-surface: '#f1f1ef'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#775a19'
  on-secondary: '#ffffff'
  secondary-container: '#fed488'
  on-secondary-container: '#785a1a'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1c1b1a'
  on-tertiary-container: '#868382'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474746'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e9c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4201'
  tertiary-fixed: '#e6e2df'
  tertiary-fixed-dim: '#cac6c4'
  on-tertiary-fixed: '#1c1b1a'
  on-tertiary-fixed-variant: '#484645'
  background: '#faf9f7'
  on-background: '#1a1c1b'
  surface-variant: '#e3e2e0'
typography:
  display-lg:
    fontFamily: ebGaramond
    fontSize: 64px
    fontWeight: '400'
    lineHeight: 72px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: ebGaramond
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: ebGaramond
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
  headline-sm:
    fontFamily: ebGaramond
    fontSize: 24px
    fontWeight: '400'
    lineHeight: 32px
  body-lg:
    fontFamily: dmSans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0.01em
  body-md:
    fontFamily: dmSans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: dmSans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.1em
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 24px
  section-gap: 120px
---

## Brand & Style

The design system is rooted in the concept of "Quiet Luxury." It targets a discerning audience that values permanence over trends and subtlety over spectacle. The brand personality is ethereal, sophisticated, and architectural.

The visual style is a blend of **Minimalism** and **Editorial Design**. It prioritizes high-ratio whitespace, allowing product photography to breathe as if displayed in a physical gallery. The emotional response should be one of calm, confidence, and timelessness. Interfaces should feel less like a digital tool and more like a high-end coffee table book—intentional, spacious, and impeccably curated.

## Colors

The palette is restricted to three core tones to maintain an atmosphere of understated elegance.

- **Alabaster (#F9F8F6):** The primary canvas. This off-white serves as the background for all screens, providing a softer, more organic feel than pure white.
- **Deep Charcoal (#1A1A1A):** Used for primary typography, iconography, and high-contrast structural elements. It provides the necessary weight to ground the airy layout.
- **Brushed Champagne Gold (#C5A059):** Reserved for interactive accents, subtle dividers, and premium signifiers. It should be used sparingly to maintain its value.

Color application should be flat and purposeful, avoiding heavy gradients or vibrant secondary hues.

## Typography

Typography is the primary vehicle for the brand’s editorial character. 

**EB Garamond** is utilized for all headlines and display text. It should be set with generous leading to evoke a sense of literary luxury. For large display titles, a slight negative letter spacing adds a modern, tight finish.

**DM Sans** provides a functional, airy contrast for body copy and UI labels. It should be set with slightly increased letter-spacing to enhance legibility and maintain the "open" feel of the design system. All labels and secondary metadata should be set in uppercase with tracking (10%) to create a clean, architectural rhythm.

## Layout & Spacing

The layout follows a **Fixed Grid** model on desktop to preserve editorial proportions, transitioning to a fluid model on smaller devices.

- **Grid:** A 12-column grid is used for desktop (1280px max-width). 
- **Margins:** Intentional "dead space" is encouraged. Large side margins (64px+) on desktop focus the user's eye on the center-weighted content.
- **Rhythm:** A vertical spacing scale based on 8px units ensures consistency. However, section-to-section spacing should be aggressively large (e.g., 120px) to separate different narratives or collections.
- **Mobile:** Margins compress to 24px, and typography scales down to maintain balance. Multi-column layouts should reflow to a single-column stack to prioritize high-resolution imagery.

## Elevation & Depth

This design system eschews traditional shadows in favor of **Tonal Layers** and **Low-Contrast Outlines**.

Depth is created through:
- **Layering:** Elements like quick-view panels or menus should slide over the main content using the Alabaster (#F9F8F6) background, distinguished only by a subtle 1px border in a slightly darker neutral or a very soft, diffused ambient shadow (5% opacity charcoal).
- **Glassmorphism:** Use extremely subtle backdrop blurs (4px–8px) on navigation bars to allow the "soft lighting" of the imagery to bleed through, maintaining a sense of transparency and lightness.
- **Flat Depth:** Hierarchy is established primarily through size and color (Charcoal vs. Alabaster) rather than Z-axis elevation.

## Shapes

The shape language is **Sharp (0)**. 

To mirror the precision of jewelry craftsmanship and the rigidity of high-end architecture, all buttons, input fields, and image containers must have square corners. This reinforces the "Permanent" and "Minimalist" brand pillars. 

Circular elements are permitted only for functional icons (e.g., radio buttons) or for specifically displaying circular jewelry pieces (like rings or earrings) within a square frame.

## Components

### Buttons
Primary buttons are solid Charcoal (#1A1A1A) with Alabaster (#F9F8F6) text. They are rectangular, sharp-edged, and utilize the `label-caps` typography style. Secondary buttons are "Ghost" style: text-only with a Champagne Gold (#C5A059) underline that expands on hover.

### Input Fields
Inputs consist of a single 1px Charcoal bottom border. Labels use the `label-caps` style and sit above the line. Error states are indicated by a shift to a muted terracotta (avoiding bright reds to preserve the palette).

### Cards
Product cards are borderless. They feature a high-aspect-ratio image (3:4) with typography centered or left-aligned underneath. No drop shadows are used; the image should appear to sit directly on the Alabaster background.

### Lists & Dividers
Dividers are 1px thick and colored in a very faint version of Champagne Gold or a light gray-wash. They are used sparingly to separate major content blocks.

### Selection Controls
Checkboxes and radio buttons are minimal Charcoal outlines. When selected, they fill with a small Charcoal or Gold square/dot, maintaining the sharp-edged geometric theme.